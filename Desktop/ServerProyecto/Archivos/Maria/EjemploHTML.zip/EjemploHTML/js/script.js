function saludarArvhivo(){
	alert("Saludo desde archivo") 
}

function leerValores(){
	var nombre=document.getElementById('nombre').value
	alert(nombre)
}